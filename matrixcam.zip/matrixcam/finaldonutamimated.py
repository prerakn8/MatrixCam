import cv2
import sys
import numpy as np
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtCore import Qt, QTimer
import bisect
import os

ascii_gradient = " .'`^\",:;Il!i~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwbpdqkhao*#MW&8%B@$"
n_levels = len(ascii_gradient)

def intensity_to_char(val):
    index = int((val / 255) * (n_levels - 1))
    return ascii_gradient[index]

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    if hasattr(sys, '_MEIPASS'):
        # Running in a PyInstaller bundle
        base_path = sys._MEIPASS
    else:
        # Running in script or IDE
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

class AsciiCam(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("MatrixCam")
        self.setWindowIcon(QIcon(resource_path("assets/favicon.ico")))
        
        # self.greetingmenuframe = QFrame()
        # self.greetingmenuframe.setStyleSheet("background-color: black;")
        # self.greetingmenuframe.setFrameShape(QFrame.StyledPanel)
        
        # self.greetingmenuframelogoname = QLabel("MatrixCam")
        # self.greetingmenuframelogoname.setStyleSheet("color: rgb(0,255,0); border: 2px solid rgb(0,255,0); border-radius: 10px")

        self.label = QLabel()
        self.label.setFont(QFont("Courier", 8))
        self.label.setAlignment(Qt.AlignTop)
        self.label.setStyleSheet("background-color: black; color: rgb(0,255,0)")

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        self.setLayout(layout)

        self.cap = cv2.VideoCapture(0)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        resized = cv2.resize(gray, (80, 45))  # Downsize for speed

        ascii_frame = ""
        for y in range(resized.shape[0]):
            for x in range(resized.shape[1]):
                pixel_val = resized[y, x]
                closest_char = intensity_to_char(pixel_val)
                ascii_frame += closest_char
            ascii_frame += '\n'

        self.label.setText(ascii_frame)

    def closeEvent(self, event):
        self.cap.release()
        event.accept()

app = QApplication(sys.argv)
window = AsciiCam()
window.show()
sys.exit(app.exec_())